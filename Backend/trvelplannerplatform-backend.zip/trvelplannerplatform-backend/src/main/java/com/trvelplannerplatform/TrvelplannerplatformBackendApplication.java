package com.trvelplannerplatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrvelplannerplatformBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrvelplannerplatformBackendApplication.class, args);
	}

}
